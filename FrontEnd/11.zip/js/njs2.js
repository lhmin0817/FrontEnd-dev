document.write("njs2.js는 njs1.js에 포함");
document.write("<div style='color:blue; font-size:20px'>외부 자바 스크립트 파일</div>");
document.write("<script src='./js/njs3.js'><.script>");