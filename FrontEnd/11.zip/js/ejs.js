var age=23;
/*자바 스크립트를 사용해서 html 문서의 스타일 적용 */
document.write("<div style='color:red; font-size:24px;'>외부 자바스크립트 파일</div>");
document.write('<div style="color:red; font-size:24px;">외부 자바스크립트 파일</div>');
document.write("당신의 나이는 : "+age+"입니다.");