document.write("ejs1.js");
document.write("<div style='color:red; font-size:24px;'>외부 자바 스크립트 파일 </div>");